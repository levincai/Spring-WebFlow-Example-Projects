In a console window, navigate to the project directory (the one with pom.xml in it) and type : 

mvn clean jetty:run

You can now go to  the home page : 

http://localhost:8080/swfproject/


To test the web flow go to :

http://localhost:8080/swfproject/spring/testFlow

Notice how the e1s1 is appended to the URL.

