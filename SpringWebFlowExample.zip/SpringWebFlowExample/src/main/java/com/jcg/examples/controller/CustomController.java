package com.jcg.examples.controller;

public class CustomController
{

}
